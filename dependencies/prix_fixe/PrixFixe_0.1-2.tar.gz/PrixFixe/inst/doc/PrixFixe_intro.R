### R code from vignette source 'PrixFixe_intro.Rtex'

###################################################
### code chunk number 1: PrixFixe_intro.Rtex:56-57
###################################################
  library(PrixFixe, quietly = TRUE)


###################################################
### code chunk number 2: PrixFixe_intro.Rtex:81-83
###################################################
  str(example_dbsnp_ids)
  ld_regions_query_result <- getLDRegionsFromSNPs.WS(example_dbsnp_ids)


###################################################
### code chunk number 3: PrixFixe_intro.Rtex:86-92
###################################################
  ## these look funny:
  ld_regions_query_result$invalid_dbsnp_ids
  ## these look all right, but don't appear in the dbSNP database:
  ld_regions_query_result$unfound_dbsnp_ids
  ## these are known SNPs, but don't appear in the HapMap database:
  ld_regions_query_result$unmapped_dbsnps


###################################################
### code chunk number 4: PrixFixe_intro.Rtex:95-98
###################################################
  candidate_gene_table <- getGeneRegionsTable(ld_regions_query_result$ld_regions)
  head(candidate_gene_table)
  str(candidate_gene_table)


###################################################
### code chunk number 5: PrixFixe_intro.Rtex:109-112
###################################################
  candidate_edges <- getCandidateEdges.WS(candidate_gene_table$id)
  head(candidate_edges)
  str(candidate_edges)


###################################################
### code chunk number 6: PrixFixe_intro.Rtex:122-125
###################################################
  candidate_gene_sets <- tapply(candidate_gene_table$id, candidate_gene_table$region_name, I)
  candidate_gene_sets
  prix_fixe <- GPF$PF$new(candidate_gene_sets, candidate_edges, VERBOSE = TRUE)


###################################################
### code chunk number 7: PrixFixe_intro.Rtex:132-133
###################################################
  prix_fixe$G


###################################################
### code chunk number 8: PrixFixe_intro.Rtex:143-144
###################################################
  GA_run_result <- GPF$GA$run(prix_fixe, VERBOSE = TRUE)


###################################################
### code chunk number 9: PrixFixe_intro.Rtex:147-148
###################################################
  score_table <- GPF$GA$scoreVertices(GA_run_result, VERBOSE = TRUE)


###################################################
### code chunk number 10: PrixFixe_intro.Rtex:151-154
###################################################
  candidate_gene_table$score <-
    score_table$scaled_score[match(candidate_gene_table$id, score_table$vertex_name)]
  candidate_gene_table$score[is.na(candidate_gene_table$score)] <- 0


###################################################
### code chunk number 11: PrixFixe_intro.Rtex:157-161
###################################################
  ## we use the plyr package to manipulate data frames
  library(plyr)
  candidate_gene_table <- plyr::arrange(candidate_gene_table, region_name, -score)
  candidate_gene_table[c("id", "symbol", "region_name", "score")]


