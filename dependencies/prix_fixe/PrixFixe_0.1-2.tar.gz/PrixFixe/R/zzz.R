GPF <- list()

.onLoad <- function(libname, pkgname)
  {
    cat(sprintf("Welcome to %s!", pkgname))

    GPF$ID <<- initID()
    GPF$UTIL <<- initUTIL()
    GPF$PF <<- initPF()
    GPF$GA <<- initGA()
  }
