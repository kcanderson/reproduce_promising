getLDRegionsFromSNPs.WS <- function(dbsnp_ids, r_square_threshold = 0.5, upstream_padding = 100e3, downstream_padding = 10e3)
  {
    require(httr)
    require(jsonlite)
    #require(GPF)
    
    request <- list()

    request$dbsnp_ids <- GPF$ID$DBSNP$toCanonicalForm(dbsnp_ids)
    ## this is a work-around for the current web service, which accepts any string as dbSNP ID.
    ## here, i try to enforce some level of properness by calling toCanonicalForm(...) above.
    ## but when a value comes along that can't easily be coerced (by the simple pattern rules in ID$DBSNP), toCanonicalForm returns NA (signifying an 'invalid' dbSNP ID).
    ## either the web service or this function itself can report back to the user the invalid-ness of those strings.
    ## for the moment, it's easier to let the web service do as much reporting as possible, so i'll pass along (to the web service) the original strings for any post-toCanonicalForm NA values.
    foo.lix <- is.na(request$dbsnp_ids)
    request$dbsnp_ids[foo.lix] <- dbsnp_ids[foo.lix]
    
    request$r_square_threshold <- jsonlite::unbox(r_square_threshold)
    request$upstream_window <- jsonlite::unbox(upstream_padding)
    request$downstream_window <- jsonlite::unbox(downstream_padding)

    #cat(str(request)) ## DEBUG
    JSON_request <- jsonlite::toJSON(request)
    #cat(JSON_request) ## DEBUG

    HTTP_response <- httr::POST(url = "http://llama.mshri.on.ca/~mtasan/cgi/GWASnet/0.7/SnpsToGeneSets",
                                add_headers("Content-Type" = "application/json"),
                                body = JSON_request)
    JSON_response <- httr::content(HTTP_response, "text") ## this is just the body of HTTP_response.
    #cat(JSON_response) ## DEBUG
    response <- jsonlite::fromJSON(JSON_response, simplifyVector = TRUE, simplifyDataFrame = FALSE)
    #cat(str(response)) ## DEBUG

    if(!is.null(response$error)) {
      stop(response$error)
    }

    result <- response$result
    invalid_dbsnp_ids <- as.character(result$invalid_dbsnp_ids)
    unfound_dbsnp_ids <- GPF$ID$DBSNP$toFullForm(as.character(result$unfound_dbsnp_ids))
    unmapped_dbsnps <- do.call(rbind, lapply(result$unmapped_dbsnps, as.data.frame, stringsAsFactors = FALSE))
    unmapped_dbsnps$id <- GPF$ID$DBSNP$toFullForm(unmapped_dbsnps$id)

    ld_regions <- lapply(result$ld_regions, function(ld_region) {
      ncbi_genes <- do.call(rbind, lapply(ld_region$entrezgenes, as.data.frame, stringsAsFactors = FALSE))
      ncbi_genes$id <- sub("entrezgene", "NCBI_Gene", ncbi_genes$id)
      dbsnps <- do.call(rbind, lapply(ld_region$dbsnps, as.data.frame, stringsAsFactors = FALSE))
      dbsnps$id <- GPF$ID$DBSNP$toFullForm(dbsnps$id)
      return(list(start_incl = ld_region$start_incl, end_excl = ld_region$end_excl, dbsnps = dbsnps, ncbi_genes = ncbi_genes))
    })
    names(ld_regions) <- sapply(result$ld_regions, function(ld_region) ld_region$cyto)
    class(ld_regions) <- c("ld_regions", class(ld_regions))

    return(list(
      invalid_dbsnp_ids = invalid_dbsnp_ids,
      unfound_dbsnp_ids = unfound_dbsnp_ids,
      unmapped_dbsnps = unmapped_dbsnps,
      ld_regions = ld_regions
      ))
  }

getGeneRegionsTable <- function(ld_regions)
  {
    stopifnot(is(ld_regions, "ld_regions"))
    DFs <-lapply(names(ld_regions), function(ld_region_name) {
      RV <- ld_regions[[ld_region_name]]$ncbi_genes
      RV$region_name <- ld_region_name
      return(RV)
    })
    RV <- do.call(rbind, DFs)
    rownames(RV) <- NULL
    return(RV)
  }

getCandidateEdges.WS <- function(ncbi_gene_ids)
  {
    require(httr)
    require(jsonlite)
    #require(GPF)

    request <- GPF$ID$NCBI_GENE$toFullForm(ncbi_gene_ids)
    invalid_ncbi_gene_ids <- ncbi_gene_ids[is.na(request)]
    if(length(invalid_ncbi_gene_ids) > 0) {
      warning(sprintf("the following NCBI Gene IDs don't seem valid: %s", paste0(invalid_ncbi_gene_ids, collapse = ", ")), immediate. = TRUE)
    }
    request <- unique(na.omit(request))
    #cat(str(request), "\n") ## DEBUG
    JSON_request <- jsonlite::toJSON(request)
    #cat(JSON_request, "\n") ## DEBUG

    HTTP_response <- httr::POST(url = "http://llama.mshri.on.ca/~mtasan/cgi/GWASnet/0.7/ManuscriptFANCandidateEdges",
                                add_headers("Content-Type" = "application/json"),
                                body = JSON_request)
    JSON_response <- httr::content(HTTP_response, "text") ## this is just the body of HTTP_response.
    #cat(JSON_response, "\n") ## DEBUG
    response <- jsonlite::fromJSON(JSON_response, simplifyVector = TRUE, simplifyDataFrame = FALSE)
    #cat(str(response), "\n") ## DEBUG

    if(!is.null(response$error)) {
      stop(response$error)
    }

    RV <- as.data.frame(response$result, stringsAsFactors = FALSE)
    return(RV)
  }
